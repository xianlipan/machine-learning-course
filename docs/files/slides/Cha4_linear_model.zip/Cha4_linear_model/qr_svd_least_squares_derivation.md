# 最小二乘问题中 QR 分解与 SVD 分解的完整推导

## 1. 问题设定

设训练数据写成矩阵形式：

$$

X \in \mathbb{R}^{n\times p}, \qquad y \in \mathbb{R}^{n}

$$

其中：

- $n$ 是样本数
- $p$ 是特征数
- 一般讨论 $n \ge p$ 的超定情形

我们考虑最小二乘问题：

$$

\min_{w\in\mathbb{R}^p} \|y-Xw\|_2^2

$$

它的目标是：在所有 $w$ 中，找到使残差平方和最小的参数。

---

## 2. 用 QR 分解求解最小二乘

### 2.1 QR 分解的形式

若 $X$ 满列秩（即 $\operatorname{rank}(X)=p$），则可以对 $X$ 做 reduced QR 分解：

$$

X = QR

$$

其中：

- $Q \in \mathbb{R}^{n\times p}$，列正交归一：
  $$

  Q^\top Q = I_p
  
$$
- $R \in \mathbb{R}^{p\times p}$，是上三角矩阵，且可逆

把它代入原问题：

$$

\min_w \|y-Xw\|_2^2
=
\min_w \|y-QRw\|_2^2

$$

---

### 2.2 残差在列空间与正交补上的分解

因为 $Q$ 的列向量构成 $X$ 列空间的一组标准正交基，所以：

- $QQ^\top$ 是投影到 $\operatorname{col}(Q)=\operatorname{col}(X)$ 上的投影矩阵
- $I-QQ^\top$ 是投影到其正交补上的投影矩阵

因此任意 $y\in\mathbb{R}^n$ 都可以分解为：

$$

y = QQ^\top y + (I-QQ^\top)y

$$

于是：

$$

y-QRw
=
\bigl(QQ^\top y + (I-QQ^\top)y\bigr)-QRw

$$

整理得：

$$

y-QRw = Q(Q^\top y - Rw) + (I-QQ^\top)y

$$

这说明残差被分成了两部分：

1. $Q(Q^\top y-Rw)$：落在 $\operatorname{col}(Q)$ 中
2. $(I-QQ^\top)y$：落在 $\operatorname{col}(Q)^\perp$ 中

而这两个子空间互相正交，所以这两部分向量也正交。

---

### 2.3 范数拆解

由于两部分正交，有勾股公式：

$$

\|y-QRw\|_2^2
=
\|Q(Q^\top y-Rw)\|_2^2
+
\|(I-QQ^\top)y\|_2^2

$$

又因为 $Q^\top Q=I_p$，所以 $Q$ 保持长度：

$$

\|Q(Q^\top y-Rw)\|_2^2 = \|Q^\top y-Rw\|_2^2

$$

从而得到：

$$

\|y-QRw\|_2^2
=
\|Q^\top y-Rw\|_2^2
+
\|(I-QQ^\top)y\|_2^2

$$

这里第二项与 $w$ 无关，是常数。因此原问题等价于：

$$

\min_w \|y-Xw\|_2^2
\quad\Longleftrightarrow\quad
\min_w \|Q^\top y - Rw\|_2^2

$$

---

### 2.4 为什么最后变成上三角方程组

现在问题已经化成：

$$

\min_w \|Q^\top y-Rw\|_2^2

$$

这里：

- $Q^\top y \in \mathbb{R}^p$
- $R \in \mathbb{R}^{p\times p}$

如果 $X$ 满列秩，则 $R$ 可逆，因此上式的最小值可以通过令残差为 0 达到：

$$

Q^\top y - Rw = 0

$$

也就是：

$$

Rw = Q^\top y

$$

这就是一个 **上三角线性方程组**，因为 $R$ 是上三角矩阵。

因此，QR 解最小二乘的核心逻辑是：

$$

\boxed{
\min_w \|y-Xw\|_2^2
\overset{X=QR}{\Longrightarrow}
\min_w \|Q^\top y-Rw\|_2^2
\overset{R\text{ 上三角}}{\Longrightarrow}
Rw=Q^\top y
}

$$

最后用回代法（back substitution）求出 $w$。

---

## 3. 用 SVD 分解求解最小二乘

### 3.1 SVD 分解的形式

对任意 $X\in\mathbb{R}^{n\times p}$，都可以做奇异值分解：

$$

X = U\Sigma V^\top

$$

其中：

- $U\in\mathbb{R}^{n\times n}$ 是正交矩阵
- $V\in\mathbb{R}^{p\times p}$ 是正交矩阵
- $\Sigma\in\mathbb{R}^{n\times p}$ 是对角形状矩阵，其对角线上是奇异值
  $$

  \sigma_1\ge \sigma_2\ge \cdots \ge \sigma_r > 0
  
$$
  其中 $r=\operatorname{rank}(X)$

更常用的紧致形式（compact SVD）是：

$$

X = U_r \Sigma_r V_r^\top

$$

其中：

- $U_r\in\mathbb{R}^{n\times r}$
- $\Sigma_r\in\mathbb{R}^{r\times r}$
- $V_r\in\mathbb{R}^{p\times r}$

并且 $U_r^\top U_r = I_r$、$V_r^\top V_r = I_r$。

---

### 3.2 把最小二乘问题代入 SVD

原问题：

$$

\min_w \|y-Xw\|_2^2

$$

代入 $X = U_r\Sigma_r V_r^\top$：

$$

\min_w \|y-U_r\Sigma_r V_r^\top w\|_2^2

$$

由于 $U_r$ 只张成 $X$ 的列空间，我们先把 $y$ 分解到 $\operatorname{col}(U_r)$ 和其正交补上。

设：

$$

y = U_rU_r^\top y + (I-U_rU_r^\top)y

$$

则：

$$

y-U_r\Sigma_r V_r^\top w
=
U_r(U_r^\top y-\Sigma_r V_r^\top w) + (I-U_rU_r^\top)y

$$

同样因为这两部分正交，有：

$$

\|y-U_r\Sigma_r V_r^\top w\|_2^2
=
\|U_r(U_r^\top y-\Sigma_r V_r^\top w)\|_2^2
+
\|(I-U_rU_r^\top)y\|_2^2

$$

而 $U_r$ 的列正交归一，所以：

$$

\|U_r(U_r^\top y-\Sigma_r V_r^\top w)\|_2^2
=
\|U_r^\top y-\Sigma_r V_r^\top w\|_2^2

$$

因此：

$$

\min_w \|y-Xw\|_2^2
\quad\Longleftrightarrow\quad
\min_w \|U_r^\top y-\Sigma_r V_r^\top w\|_2^2

$$

---

### 3.3 引入新变量，把问题变成对角系统

设：

$$

z = V_r^\top w \in \mathbb{R}^r

$$

则问题变成：

$$

\min_z \|U_r^\top y-\Sigma_r z\|_2^2

$$

因为 $\Sigma_r$ 是对角矩阵：

$$

\Sigma_r =
\begin{bmatrix}
\sigma_1 & & \\
& \ddots & \\
& & \sigma_r
\end{bmatrix}

$$

所以这个问题实际上等价于：

$$

\min_{z_1,\dots,z_r}
\sum_{i=1}^r (u_i^\top y - \sigma_i z_i)^2

$$

每个方向都可以单独最小化。由于 $\sigma_i>0$，最优时有：

$$

u_i^\top y - \sigma_i z_i = 0

$$

即：

$$

z_i = \frac{u_i^\top y}{\sigma_i}, \qquad i=1,\dots,r

$$

写成矩阵形式：

$$

z = \Sigma_r^{-1} U_r^\top y

$$

再代回 $w = V_r z$，得到：

$$

w = V_r \Sigma_r^{-1} U_r^\top y

$$

这就是满列秩或紧致秩空间内的最小二乘解。

---

### 3.4 伪逆形式

更一般地，SVD 给出的最小二乘最小范数解可以统一写成：

$$

w^\star = X^+ y

$$

其中 $X^+$ 是 Moore-Penrose 伪逆：

$$

X^+ = V \Sigma^+ U^\top

$$

$\Sigma^+$ 的构造方式是：

- 对非零奇异值 $\sigma_i$，取倒数 $1/\sigma_i$
- 对零奇异值，保持为 0

于是：

$$

\boxed{
w^\star = V\Sigma^+U^\top y
}

$$

这个公式在秩亏情形仍然成立。

---

## 4. QR 与 SVD 的本质区别

### QR 路线

QR 的核心是：

1. 先把 $X$ 的列向量正交化
2. 把原来的最小二乘问题化成
   $$

   \min_w \|Q^\top y - Rw\|_2^2
   
$$
3. 再利用 $R$ 的上三角结构做回代

它强调的是：

- 列空间
- 正交投影
- 上三角线性系统

---

### SVD 路线

SVD 的核心是：

1. 先找到 $X$ 的奇异方向
2. 把问题变成
   $$

   \min_z \|U_r^\top y - \Sigma_r z\|_2^2
   
$$
3. 在每个奇异方向上分别求解
4. 最后映射回原参数空间

它强调的是：

- 数据的主方向
- 奇异值大小
- 哪些方向信息强、哪些方向退化

SVD 直接把问题写成：

$$

w^\star = V\Sigma^+U^\top y

$$

这时：

- 很小的奇异值会被直接暴露出来
- 零奇异值也能自然处理
- 更容易解释多重共线性与秩亏问题

因此在数值计算上，SVD 通常更稳。

---

## 5. 一句话总结版

- **QR**：把最小二乘问题化成一个上三角方程组
- **SVD**：把最小二乘问题拆到奇异值方向上分别求解