import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import (
    AgglomerativeClustering,
    KMeans,
    DBSCAN,
    MeanShift,
    estimate_bandwidth,
    SpectralClustering
)
from sklearn.mixture import GaussianMixture

# =========================
# 0. 让 matplotlib 尽量支持中文
# =========================
plt.rcParams["font.sans-serif"] = [
    "SimHei", "Microsoft YaHei", "Arial Unicode MS", "Noto Sans CJK SC"
]
plt.rcParams["axes.unicode_minus"] = False

# =========================
# 1. 读取数据
# =========================
file_path = "王者荣耀英雄基础属性与定位机制分析.csv"   # 改成你的文件名
df = pd.read_csv(file_path, encoding="gbk")

print("原始数据形状：", df.shape)
print("列名：")
print(df.columns.tolist())

# =========================
# 2. 去掉不用的列
#    - 英雄：保留名字，但不参与聚类
#    - 攻击范围：去掉
#    - 最后两列定位：去掉（标签信息）
# =========================
hero_names = df["英雄"].copy()

X = df.drop(columns=["英雄", "攻击范围", "主要定位", "次要定位 "]).copy()

# =========================
# 3. 处理“最大攻速”这种百分号字段
# =========================
if "最大攻速" in X.columns:
    X["最大攻速"] = X["最大攻速"].astype(str).str.replace("%", "", regex=False).astype(float)

print("\n用于聚类的特征列：")
print(X.columns.tolist())

# =========================
# 4. 标准化
# =========================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# =========================
# 5. PCA降到2维，仅用于可视化
# =========================

from sklearn.manifold import TSNE
X_vis = TSNE(n_components=2, perplexity=10, random_state=42).fit_transform(X_scaled)

# =========================
# 6. 六种聚类算法
#    对需要指定聚类数的统一设为5
# =========================
n_clusters = 5

models = {
    "层次聚类": AgglomerativeClustering(n_clusters=n_clusters, linkage="ward"),
    "KMeans": KMeans(n_clusters=n_clusters, random_state=42, n_init=20),
    "GMM": GaussianMixture(n_components=n_clusters, random_state=42, covariance_type="full"),
    "DBSCAN": DBSCAN(eps=1.8, min_samples=3),
    "MeanShift": MeanShift(
        bandwidth=estimate_bandwidth(X_scaled, quantile=0.25, n_samples=len(X_scaled)),
        bin_seeding=True
    ),
    "谱聚类": SpectralClustering(
        n_clusters=n_clusters,
        affinity="nearest_neighbors",
        n_neighbors=10,
        assign_labels="kmeans",
        random_state=42
    )
}

# =========================
# 7. 拟合并保存结果
# =========================
cluster_results = pd.DataFrame({"英雄": hero_names})

labels_dict = {}

for name, model in models.items():
    if name == "GMM":
        labels = model.fit_predict(X_scaled)
    else:
        labels = model.fit_predict(X_scaled)

    labels_dict[name] = labels
    cluster_results[name] = labels

print("\n各算法聚类标签预览：")
print(cluster_results.head())

# 可选：保存结果
cluster_results.to_csv("英雄六种聚类结果.csv", index=False, encoding="utf-8-sig")
print("\n已保存：英雄六种聚类结果.csv")

# =========================
# 8. 画六种算法对比图
# =========================
fig, axes = plt.subplots(2, 3, figsize=(20, 14))
axes = axes.ravel()

for ax, (name, labels) in zip(axes, labels_dict.items()):
    unique_labels = np.unique(labels)

    # 先画点
    scatter = ax.scatter(X_vis[:, 0], X_vis[:, 1], c=labels, s=40)

    # 再写名字
    for i, hero in enumerate(hero_names):
        ax.text(
            X_vis[i, 0] + 0.03,
            X_vis[i, 1] + 0.03,
            hero,
            fontsize=8
        )

    # 统计簇数（DBSCAN可能有-1噪声点）
    if -1 in unique_labels:
        n_found = len(set(labels)) - 1
        title_text = f"{name}\n簇数={n_found}（含噪声点）"
    else:
        n_found = len(set(labels))
        title_text = f"{name}\n簇数={n_found}"

    ax.set_title(title_text, fontsize=13)
    ax.set_xlabel("PCA 1")
    ax.set_ylabel("PCA 2")
    ax.grid(alpha=0.3)

plt.tight_layout()
plt.show()