"""从官方原始文件构建课堂小数据。默认运行 notebook 不需要此脚本。"""
from pathlib import Path
import argparse, urllib.request, urllib.parse, zipfile
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
NASA_COLUMNS='kepid,kepoi_name,koi_disposition,koi_period,koi_duration,koi_depth,koi_prad,koi_steff,koi_slogg,koi_srad,koi_kepmag'
def nasa(source=None):
    if source is None:
        url='https://exoplanetarchive.ipac.caltech.edu/TAP/sync?'+urllib.parse.urlencode({'query':'select '+NASA_COLUMNS+' from cumulative','format':'csv'})
        source=ROOT/'data/nasa_download.csv';urllib.request.urlretrieve(url,source)
    df=pd.read_csv(source);df.to_csv(ROOT/'data/kepler_koi.csv',index=False)
    print('NASA',df.shape,df.koi_disposition.value_counts().to_dict())
def fma(folder):
    folder=Path(folder)
    t=pd.read_csv(folder/'tracks.csv',header=[0,1],index_col=0,low_memory=False)
    chosen=t[(t[('set','subset')]=='small') & t[('track','genre_top')].isin(['Rock','Electronic','Hip-Hop','Folk'])]
    f=pd.read_csv(folder/'features.csv',header=[0,1,2],index_col=0)
    cols=[c for c in f.columns if c[1] in ['mean','std'] and c[0] in ['mfcc','spectral_centroid','spectral_bandwidth','spectral_rolloff','zcr','rmse']]
    out=f.loc[chosen.index,cols].copy();out.columns=['_'.join(c) for c in cols]
    for k,c in {'title':('track','title'),'artist':('artist','name'),'artist_id':('artist','id'),'genre':('track','genre_top')}.items():out[k]=chosen[c]
    out.index.name='track_id';out.to_csv(ROOT/'data/fma_four_genres.csv')
    print('FMA',out.shape,out.genre.value_counts().to_dict())
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--nasa-local');p.add_argument('--fma-folder');a=p.parse_args()
    nasa(a.nasa_local)
    if a.fma_folder:fma(a.fma_folder)
    else:print('音乐数据：下载 https://os.unil.cloud.switch.ch/fma/fma_metadata.zip 解压后指定 --fma-folder。')
