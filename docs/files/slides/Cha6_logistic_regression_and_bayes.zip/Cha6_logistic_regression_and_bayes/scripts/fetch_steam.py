"""重新采集中文公开评论；默认使用课堂包数据即可，无需运行本脚本。"""
from pathlib import Path
import requests, time, json, hashlib, re
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
URL = 'https://api.steampowered.com/IUserReviewsService/GetAppReviews/v1/'
GAMES = {2358720:'黑神话：悟空', 413150:'星露谷物语', 1426210:'双人成行'}
def main():
    rows=[]
    for appid,game in GAMES.items():
        for label in [1,2]:
            cursor='*'
            for page in range(7):
                params={'appid':appid,'languages':['schinese'],'filter':1,'review_type':label,'num_per_page':100,'cursor':cursor}
                for attempt in range(4):
                    r=requests.get(URL,params={'input_json':json.dumps(params)},timeout=60)
                    if r.status_code!=429: break
                    time.sleep(10*(attempt+1))
                r.raise_for_status()
                d=r.json().get('response',r.json())
                reviews=d.get('reviews',[])
                if not reviews:break
                for x in reviews:
                    text=re.sub(r'\[/?[^\]]+\]',' ',x['review'])
                    text=re.sub(r'https?://\S+',' ',text)
                    text=re.sub(r'\s+',' ',text).strip()
                    if len(re.findall(r'[\u4e00-\u9fff]',text))<10 or len(text)>1500:continue
                    rows.append({'review_id':x['recommendationid'],'game':game,'appid':appid,'text':text,'recommended':int(x['voted_up']),'created':x['timestamp_created'],'author_group':hashlib.sha256(x['author']['steamid'].encode()).hexdigest()[:20]})
                nxt=d.get('cursor')
                print(game,label,page,len(rows),flush=True)
                if not nxt or nxt==cursor:break
                cursor=nxt
                time.sleep(1.2)
    df=pd.DataFrame(rows).drop_duplicates('review_id').drop_duplicates('text')
    # 每游戏每类最多500条；这是刻意平衡的教学样本，不代表平台好评率。
    df=pd.concat([g.head(500) for _,g in df.groupby(['game','recommended'])]).reset_index(drop=True)
    df.to_csv(ROOT/'data/steam_reviews.csv',index=False)
    print(df.groupby(['game','recommended']).size())
if __name__=='__main__':main()
