# 音乐特征提取：从一首真实歌曲到50维向量

打开 `音乐特征提取_从音频到50维.ipynb`，从上到下运行即可。已保存执行输出，默认不联网，不需要GPU。

## 在VSCode运行

1. 完整解压，打开包含Notebook、audio、assets的文件夹。外层文件夹可以任意改名。
2. 选择Python 3.11–3.13环境，在该环境终端运行：
   ```bash
   python -m pip install -r requirements.txt
   ```
3. 在Notebook右上角选择同一个环境作为内核。
4. 如果找不到音频，把第一个代码单元的`ROOT = Path.cwd()`改为实际路径，如`ROOT = Path(r"D:\Agent\音乐特征实验")`。
5. 运行全部代码。音频播放若不兼容OGG，可用系统播放器打开audio中的文件。

可使用此前课程环境，但这里新增了librosa和soundfile依赖。首次运行librosa可能有即时编译开销。

## 学生将看到什么

- 真实歌曲播放器、全曲波形、局部25毫秒波形。
- 分帧与Hann窗的作用，一帧波形如何成为频谱。
- RMS、ZCR、频谱重心、频谱带宽、85%滚降点的时间变化与手算核对。
- 功率谱经过128个Mel滤波器、取对数、DCT，得到20个MFCC。
- 25条时间序列分别取均值和标准差，得到50维特征向量。
- 完整50列名称、取值与中文释义。
- 打乱时间顺序、比较歌曲片段两个小实验。

## 文件与输出

- `audio/Karissa_Hobbs_-_Lets_Go_Fishin.hq.ogg`：公开下载的完整音乐文件，约132.989秒、44.1kHz双声道；并非录音室原始母带。
- `outputs/song_50_features.csv`：一行50列，可作为一致提取流程中的模型输入。
- `outputs/50个特征逐项说明.csv`：50行逐项释义与实际数值。
- `outputs/frame_features.csv`：每帧的25个特征，加时间列，便于追溯。
- `outputs/*.png`：8张讲解图，可直接放进PPT。
- `fma_50_columns.json`：与前一份音乐分类Notebook对应的列顺序。
- `scripts/download_audio.py`：备用下载脚本，课堂无需运行。
- `来源与参数.json`：下载来源、日期、SHA256与显式参数。
- `assets`：中文字体与SIL OFL许可。

## 与之前FMA模型的关系

50维的特征组、mean/std统计与列名对应之前课堂，但本例不是历史FMA特征CSV的逐位复现。统一采样率、现代librosa版本、Mel归一化、全曲与片段等因素都影响数值。训练与预测必须用一致的提取流程，不能只看列名相同就直接混用。本Notebook不输出风格预测。

旧列名`rmse`表示RMS（均方根振幅），不是监督学习里的均方根误差。滚降点在此按传入的幅度谱累计量定义；Mel则使用功率谱。标准差使用ddof=0。

## 音乐来源和授权标注

作品：Let's Go Fishin'；作者：Karissa Hobbs；来源FMA，下载镜像为librosa官方数据仓库。

官方数据仓库当前toml标注CC BY-NC-SA 4.0；旧txt标注CC BY 3.0。本包保留原始两份元数据，按当前较严格的CC BY-NC-SA 4.0条件提供音频（署名、非商业、相同方式共享），不对音乐另行宣称版权。源OGG文件未修改；Notebook中单声道化、重采样用于分析。Notebook生成的30秒试听仅是分析数据的一段。

- 原曲页面：https://freemusicarchive.org/music/Karissa_Hobbs/Age_of_Flowers/09_Lets_Go_Fishin/
- 官方音频镜像：https://github.com/librosa/data/tree/main/audio
- 当前标注许可：https://creativecommons.org/licenses/by-nc-sa/4.0/
- 方法参考：https://github.com/mdeff/fma/blob/master/features.py
