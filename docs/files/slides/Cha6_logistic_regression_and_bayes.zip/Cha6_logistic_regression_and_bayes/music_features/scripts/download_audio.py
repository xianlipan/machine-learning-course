"""可选：从librosa官方数据镜像下载同一首歌，无需账号或API key。"""
from pathlib import Path
from urllib.request import urlretrieve
ROOT = Path(__file__).resolve().parents[1]
base = 'https://raw.githubusercontent.com/librosa/data/main/audio/'
name = 'Karissa_Hobbs_-_Lets_Go_Fishin'
if __name__ == '__main__':
    dest = ROOT / 'audio'
    dest.mkdir(exist_ok=True)
    for suffix in ['.hq.ogg', '.txt', '.toml']:
        path = dest / (name + suffix)
        urlretrieve(base + name + suffix, path)
        print('已下载：', path.name)
